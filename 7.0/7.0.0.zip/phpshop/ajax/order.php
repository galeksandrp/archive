<?php

/**
 * ������� � ������
 * @package PHPShopAjaxElements
 */
session_start();
$_classPath = "../";
include($_classPath . "class/obj.class.php");
PHPShopObj::loadClass("base");
$PHPShopBase = new PHPShopBase($_classPath . "inc/config.ini");
PHPShopObj::loadClass("array");
PHPShopObj::loadClass("orm");
PHPShopObj::loadClass("product");
PHPShopObj::loadClass("system");
PHPShopObj::loadClass("valuta");
PHPShopObj::loadClass("string");
PHPShopObj::loadClass("cart");
PHPShopObj::loadClass("security");
PHPShopObj::loadClass("user");
PHPShopObj::loadClass("lang");
PHPShopObj::loadClass("order");
PHPShopObj::loadClass("nav");
PHPShopObj::loadClass("parser");
PHPShopObj::loadClass('payment');

$PHPShopSystem = new PHPShopSystem();
$PHPShopLang = new PHPShopLang(array('locale' => $_SESSION['lang'], 'path' => 'shop'));
$PHPShopNav = new PHPShopNav();

// ������ �����
$PHPShopValutaArray = new PHPShopValutaArray();

// ������
$PHPShopModules = new PHPShopModules($_classPath . "modules/");

$payment_id = intval($_REQUEST['payment_id']);
if (!empty($payment_id)) {
    $PHPShopPayment = new PHPShopPayment($payment_id);
    $price = (int) $PHPShopPayment->getParam('price');

    $PHPShopCart = new PHPShopCart();
    if ($price < 2)
        $PHPShopCart->priceColumn = 'price';
    else
        $PHPShopCart->priceColumn = 'price' . $price;

    foreach ($PHPShopCart->_CART as $id => $product) {

        // ������� �����
        $PHPShopCart->del($id);
        
        $_REQUEST['addname'] = $product['addname'];

        // ��������� ����� � ������ ����� ����
        $PHPShopCart->add($id, $product['num'], $product['parent']);
    }
}

// ����������� ������ ������
PHPShopObj::importCore('order');
$SysValue['dir']['templates'] = '../../' . $SysValue['dir']['templates'];

$PHPShopOrder = new PHPShopOrder();
$PHPShopOrder->PHPShopCart->priceColumn = $PHPShopCart->priceColumn;
$cart = $PHPShopOrder->product();

exit($cart);
