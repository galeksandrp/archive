<!DOCTYPE html>
<html lang="@code@">
    <head>
        <meta charset="@charset@">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="@title@ - @version@">
        <meta name="author" content="PHPShop Software">
        <link rel="apple-touch-icon" href="./apple-touch-icon.png">
        <link rel="icon" href="./favicon.ico"> 
        <title>@title@</title>

        <!-- Theme switch -->
        <script>
            (function () {
                var STORAGE_KEY = 'phpshop_theme';
                var saved = localStorage.getItem(STORAGE_KEY) || 'light';

                /* ���� � ���������� ���� ������� */
                var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
                var effective = (saved === 'auto') ? (prefersDark ? 'dark' : 'light') : saved;

                /* ��������� ������� */
                if (effective === 'light') {
                    document.documentElement.removeAttribute('data-theme');
                } else {
                    document.documentElement.setAttribute('data-theme', effective);
                }

                window.__phpshop_theme_choice = saved;
                window.__phpshop_theme_effective = effective;
            })();
        </script>

        <!-- Bootstrap -->
        <link href="./css/bootstrap.min.css" rel="stylesheet">
        <link href="./css/bootstrap-theme-light.css" rel="stylesheet">
        <link href="./css/bootstrap-theme-dark.css" rel="stylesheet">
        <link href="./css/bootstrap-theme-dim.css" rel="stylesheet">
        <link href="./css/bootstrap-select.min.css" rel="stylesheet">
        <link href="./css/signin.css" rel="stylesheet">
        <link href="./css/bar.css" rel="stylesheet">
        <link href="./css/messagebox.min.css" rel="stylesheet">
        <link href="./css/font-awesome.min.css" rel="stylesheet">
        <link href="./css/fontawesome-light.css" rel="stylesheet">

    </head>

    <body id="form-signin">

        <!-- jQuery -->
        <script src="js/jquery-1.11.0.min.js"></script>

        <!-- Localization -->
        <script src="../locale/@lang@/gui.js" data-rocketoptimized="false" data-cfasync="false"></script>

        <header class="bar bar-nav navbar-action visible-xs">
            <h1 class="title">{�����������}</h1>
        </header>

        <!-- container -->
        <div class="container">

            <div class="row">
                <div class="login-box">

                    <form class="form-signin "  method="post" action="./">

                        <div class="login-logo">
                            <a href="../../" title="{��������� � �������}">
                                @logo@
                                <span class="login-logo-text">@brand@</span>
                            </a>
                        </div>
                        <div class="input-group @error@">
                            <span class="input-group-addon" id="input-group-addon1"><span class="glyphicon glyphicon-user"></span></span>
                            <input autocomplete="off" type="text" name="log" class="form-control" value="@user@" placeholder="{�����}" required @autofocus@ @readonly@ tabindex="1">
                        </div>
                        <div class="input-group @error@">
                            <span class="input-group-addon" id="input-group-addon2"><a href="#" class="password-view" tabindex="-1" title="{�������� ������}"><span class="glyphicon glyphicon-eye-close"></span></a></span>
                            <input autocomplete="off" type="password" name="pas" class="form-control" value="@password@" placeholder="{������}"  required @readonly@ tabindex="2">
                        </div>

                        <div class="checkbox">
                            <div class="@hide@">
                                <label>
                                    <input type="checkbox" name="actionHash" value="true" id="remember-me" @disabled@ tabindex="-1"> {������������ ������}
                                </label>
                            </div>
                            <div></div>
                            <div class="pull-right">
                                <div class="btn-group btn-group-sm theme-switch" role="group" aria-label="theme-switch">
                                    <button type="button" class="btn btn-default" data-theme-value="light" title="{������� ����}">
                                        <i class="fal fa-sun"></i>
                                    </button>
                                    <button type="button" class="btn btn-default" data-theme-value="dim" title="{����������� ����}">
                                        <i class="fal fa-cloud"></i>
                                    </button>
                                    <button type="button" class="btn btn-default" data-theme-value="dark" title="{Ҹ���� ����}">
                                        <i class="fal fa-moon"></i>
                                    </button>
                                    <button type="button" class="btn btn-default" data-theme-value="auto" title="��� � �������">
                                        <i class="fal fa-adjust"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <button class="btn btn-primary btn-block" type="submit" tabindex="3">{�����}</button>
                        <input type="hidden" name="actionID" value="true">
                        <input type="hidden" name="actionList[actionHash]" value="actionHash">
                        <input type="hidden" name="actionList[actionID]" value="actionEnter">
                    </form>

                    <div class="login-footer">
                        {������} @version@ 
                    </div>

                </div>
            </div>
        </div> <!-- /container -->

        <!-- Fixed mobile bar -->
        <div class="bar-padding-fix visible-xs"> </div>
        <nav class="navbar navbar-statick navbar-fixed-bottom bar bar-tab visible-xs" role="navigation">
            <a class="tab-item active" href="../../">
                <span class="icon icon-home"></span>
                <span class="tab-label">{�����}</span>
            </a>
            <a class="tab-item" href="?path=order">
                <span class="icon icon-download"></span>
                <span class="tab-label">{������}</span>
            </a>
            <a class="tab-item" href="?path=catalog">
                <span class="icon icon-compose"></span>
                <span class="tab-label">{����}</span>
            </a>
            <a class="tab-item"  href="?path=shopusers">
                <span class="icon icon-person"></span>
                <span class="tab-label">{����������}</span>
            </a>
        </nav>
        <!--/ Fixed mobile bar -->


        <!-- Notification -->
        <div id="message" class="hide">@notification@</div>
        <!--/ Notification -->

        <script src="./js/bootstrap.min.js" data-rocketoptimized="false" data-cfasync="false"></script>
        <script src="./js/bootstrap-select.min.js" data-rocketoptimized="false" data-cfasync="false"></script>
        <script src="./js/messagebox.min.js" data-rocketoptimized="false" data-cfasync="false"></script>
        <script src="./js/signin.js" data-rocketoptimized="false" data-cfasync="false"></script>
    </body>
</html>