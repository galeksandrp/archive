<?php

/**
 * �������� �����-������
 * @author PHPShop Software
 * @version 1.4
 * @package PHPShopForms
 */
session_start();

use Shuchkin\SimpleXLSXGen;

$_classPath = "../phpshop/";
include($_classPath . "class/obj.class.php");
PHPShopObj::loadClass("base");
$PHPShopBase = new PHPShopBase($_classPath . "inc/config.ini");
PHPShopObj::loadClass("array");
PHPShopObj::loadClass("orm");
PHPShopObj::loadClass("system");
PHPShopObj::loadClass("valuta");
PHPShopObj::loadClass("product");
PHPShopObj::loadClass("category");

$PHPShopValutaArray = new PHPShopValutaArray();
$PHPShopSystem = new PHPShopSystem();

// ����������
$PHPShopBase->checkMultibase();

class PHPShopPriceSave {

    var $csv;
    var $content;
    var $title_bgcolor = '#2FA4E7';
    var $title_color = '#FFFFFF';

    function __construct() {
        $this->debug = false;
        $this->objBase = $GLOBALS['SysValue']['base']['products'];
        require_once '../phpshop/lib/simplexlsx/SimpleXLSXGen.php';

        // SSL
        if (!empty($_SERVER['HTTPS']) && 'off' !== strtolower($_SERVER['HTTPS']))
            $this->ssl = 'https://';
        else
            $this->ssl = 'http://';
    }
    
    function select() {
        global $PHPShopSystem, $PHPShopValutaArray;
        if (is_numeric($_GET['catId']))
            $str = " (category=".$_GET['catId']." or dop_cat LIKE '%#".$_GET['catId']."#%') and ";
        else {
            $str = null;
            $queryMultibase = $this->queryMultibase();
            if (!empty($queryMultibase))
                $str = ' ' . $queryMultibase;
        }

        // ��������� ������
        $system_currency = $PHPShopSystem->getValue('dengi');
        $ValutaArray = $PHPShopValutaArray->getArray();
        $valuta = $ValutaArray[$system_currency]['code'];

        // �������� ������ ��� ����� �����������
        if ($PHPShopSystem->getSerilizeParam('admoption.user_price_activate') == 1 and empty($_SESSION['UsersId']))
            $user_price_activate = true;

        $PHPShopOrm = new PHPShopOrm();
        $PHPShopOrm->comment = __CLASS__ . '.' . __FUNCTION__;
        $PHPShopOrm->debug = $this->debug;
        $result = $PHPShopOrm->query("select * from " . $this->objBase . " where " . $str . " enabled='1'");
        
        // �������
        if(is_numeric($_GET['catId']))
        $this->category_name = (new PHPShopCategory((int)$_GET['catId']))->getName();
        else $this->category_name="��� ��������";

        // ���������
        $this->content[] = ['<b><style bgcolor="' . $this->title_bgcolor . '" color="' . $this->title_color . '">' . PHPShopString::win_utf8('�������') . '</style></b>', '<b><style bgcolor="' . $this->title_bgcolor . '" color="' . $this->title_color . '">' . PHPShopString::win_utf8('������������') . '</style></b>', '<b><style bgcolor="' . $this->title_bgcolor . '" color="' . $this->title_color . '">' . PHPShopString::win_utf8('���� ' . $valuta) . '</style></b>','<b><style bgcolor="' . $this->title_bgcolor . '" color="' . $this->title_color . '">' . PHPShopString::win_utf8('�������') . '</style></b>','<style bgcolor="' . $this->title_bgcolor . '" color="' . $this->title_color . '"> </style>'];

        while ($row = mysqli_fetch_array($result)) {
            $price_array = array($row['price'], $row['price2'], $row['price3'], $row['price4'], $row['price5']);
            $price = PHPShopProductFunction::GetPriceValuta($row['id'], $price_array, $row['baseinputvaluta']);

            // ���� ���� ���������� ������ ����� ����������
            if (!empty($user_price_activate) and ! $_SESSION['UsersId']) {
                $price = "~";
            }
            $url = $this->ssl. $_SERVER['SERVER_NAME'] . '/shop/UID_'.$row['id'].'.html';
            $url_order = $this->ssl. $_SERVER['SERVER_NAME'] . '/order/?from=html&id='.$row['id'];
            
            if(empty($row['sklad']))
                $items='<style color="#008000">����</style>';
            else $items='<style color="#FF0000">���</style>';
            
            
            $this->content[] = [PHPShopString::win_utf8($row['uid']), '<a href="'.$url.'">'.PHPShopString::win_utf8($row['name']).'</a>', PHPShopString::win_utf8($price),PHPShopString::win_utf8($items),'<a href="'.$url_order.'">'.PHPShopString::win_utf8('������').'</a>'];
        }
    }

    // ����� ����������
    function compile() {
        $file = "price/price-" . $_SERVER['SERVER_NAME'] . "-" . date("d-m-y-His") . ".xlsx";
        $cat_name=PHPShopString::win_utf8($this->category_name).' '.PHPShopDate::get();
        SimpleXLSXGen::fromArray($this->content, $cat_name)->saveAs($file);
        header("Location: " . $file);
    }

    public function queryMultibase() {

        // ����������
        if (defined("HostID") or defined("HostMain")) {

            $multi_cat = [];
            $multi_dop_cats = null;

            // �� �������� ������� ��������
            $where['skin_enabled '] = "!='1'";

            if (defined("HostID"))
                $where['servers'] = " REGEXP 'i" . HostID . "i'";
            elseif (defined("HostMain"))
                $where['skin_enabled'] .= ' and (servers ="" or servers REGEXP "i1000i")';

            $PHPShopOrm = new PHPShopOrm($GLOBALS['SysValue']['base']['categories']);
            $PHPShopOrm->debug = $this->debug;
            $data = $PHPShopOrm->getList(array('id'), $where);

            foreach ($data as $row) {
                $multi_cat[] = $row['id'];
                $multi_dop_cats .= ' OR dop_cat LIKE \'%#' . $row['id'] . '#%\' ';
            }

            if (count($multi_cat) > 0)
                $multi_select = ' (category IN (' . implode(',', $multi_cat) . ') ' . $multi_dop_cats . ') and ';

            return $multi_select;
        }
    }

}

$PHPShopPriceSave = new PHPShopPriceSave();
$PHPShopPriceSave->select();
$PHPShopPriceSave->compile();
