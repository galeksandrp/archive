/*671*/
ALTER TABLE `phpshop_orders` ADD `status_update` ENUM('0','1') NOT NULL DEFAULT '0';
ALTER TABLE `phpshop_orders` ADD INDEX(`status_update`);