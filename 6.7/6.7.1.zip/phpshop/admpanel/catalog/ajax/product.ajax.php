<?php

session_start();
$_classPath = "../../../";
include($_classPath . "class/obj.class.php");
PHPShopObj::loadClass(array("base", "system", "admgui", "orm", "date", "xml", "security", "string", "parser", "mail", "lang"));
$subpath[0] = 'catalog';

$PHPShopBase = new PHPShopBase($_classPath . "inc/config.ini", true, true);
$PHPShopBase->chekAdmin();

PHPShopObj::loadClass('valuta');
PHPShopObj::loadClass('category');
PHPShopObj::loadClass('sort');

// ��������� ���������
$PHPShopSystem = new PHPShopSystem();
$PHPShopLang = new PHPShopLang(array('locale' => $_SESSION['lang'], 'path' => 'admin'));

// �������� GUI
$PHPShopInterface = new PHPShopInterface();

$PHPShopModules = new PHPShopModules($_classPath . "modules/");

/**
 * ����� �������
 */
// ��������� �����
$memory = $PHPShopInterface->getProductTableFields();

// ��������� ������
if (PHPShopString::is_mobile()) {
    $PHPShopInterface->mobile = true;
    $product_class = null;
} elseif ($PHPShopSystem->getSerilizeParam('admoption.fast_view') != 1)
    $product_class = ' adminModal';

// ��������������
if (!empty($memory['catalog.option']['sort'])) {
    $PHPShopSortArray = new PHPShopSortArray();
    $PHPShopSort = $PHPShopSortArray->getArray();
    $PHPShopSortCategoryArray = new PHPShopSortCategoryArray();
    $PHPShopSortCategory = $PHPShopSortCategoryArray->getArray();
} else {
    $PHPShopSort = array();
    $PHPShopSortCategory = array();
}

if (isset($_GET['where']['category']))
    unset($_GET['cat']);

if (empty($_GET['core']))
    $_GET['core'] = null;

// ��� ������
switch ($_GET['core']) {
    case 'reg':
        $core = 'REGEXP';
        break;
    case 'eq':
        $core = ' = ';
        break;
    default: $core = 'REGEXP';
}

// ID ������ eq
if (!empty($_GET['where']['id']))
    $core = ' = ';

if (empty($_GET['sub']))
    $_GET['sub'] = null;

$where = false;

if (isset($_GET['start']))
    $limit = array('limit' => $_GET['start'] . ',' . $_GET['length']);
else
    $limit = array('limit' => 300);

if (isset($_GET['cat']) or isset($_GET['sub'])) {

    if (!empty($_GET['cat']) or $_GET['sub'] == 'csv' or isset($_GET['sub'])) {
        $where['(category'] = "=" . intval($_GET['cat']) . ' OR category=1000002  OR dop_cat LIKE \'%#' . intval($_GET['cat']) . '#%\') ';
    }

    // ����������
    if ($_GET['cat'] == 1000005 and ! empty($_COOKIE['idselect'])) {
        $idselect = json_decode($_COOKIE['idselect'], true);

        if (is_array($idselect)) {
            unset($where['(category']);
            $where['id'] = sprintf(' IN (%s)', implode(',', $idselect));
        }
    }

    // ����������� ���������� �� �������� ��������
    $PHPShopCategory = new PHPShopCategory(intval($_GET['cat']));
    switch ($PHPShopCategory->getParam('order_to')) {
        case(1): $order_direction = "";
            break;
        case(2): $order_direction = " desc";
            break;
        default: $order_direction = "";
            break;
    }
    switch ($PHPShopCategory->getParam('order_by')) {
        case(1): $order = array('order' => 'name' . $order_direction);
            break;
        case(2):
            $order = array('order' => 'price' . $order_direction);
            break;
        case(3): $order = array('order' => 'num' . $order_direction . ', items' . $order_direction . ', enabled' . $order_direction . ', datas desc');
            break;
        default: $order = array('order' => 'num' . $order_direction . ', items' . $order_direction . ', enabled' . $order_direction . ', datas desc');
            break;
    }
} else {

    $order = array('order' => 'enabled desc, datas desc');
}

// ����������� ���������� �� JSON
if (is_array($_GET['order']) and ! empty($_SESSION['jsort'][$_GET['order']['0']['column']])) {
    $order = array('order' => $_SESSION['jsort'][$_GET['order']['0']['column']] . ' ' . $_GET['order']['0']['dir']);
}

// ����������� �����
if (!empty($_GET['where']) and is_array($_GET['where'])) {
    foreach ($_GET['where'] as $k => $v) {

        if (isset($v) and $v != '') {

            if ($v == 'null')
                $v = '';

            // ��������������
            if (is_array($v)) {
                $v = array_values(array_diff($v, [''])); // ������� ������ �������� � ����� ������.
                $vendor = null;
                foreach ($v as $kk => $vv) {
                    if ($kk == 0 and ! empty($vv))
                        $vendor .= "  LIKE '%" . PHPShopSecurity::TotalClean($vv) . "%'";
                    elseif (!empty($vv))
                        $vendor .= " and " . PHPShopSecurity::TotalClean($k) . " LIKE '%" . PHPShopSecurity::TotalClean($vv) . "%'";
                }

                if (!empty($vendor))
                    $where[PHPShopSecurity::TotalClean($k)] = $vendor;
            }

            // ���������
            else if ($k == "category") {
                $where['(category'] = "=" . intval($v) . ' OR dop_cat LIKE \'%#' . intval($v) . '#%\') ';
            } else
                $where[PHPShopSecurity::TotalClean($k)] = " " . $core . " '" . PHPShopSecurity::TotalClean($v) . "'";
        }
    }
}

// �������� ��������������
if (!empty($_GET['sort'])) {
    $sort_array = explode(":", $_GET['sort']);
    $PHPShopSortSearch = new PHPShopSortSearch($sort_array[0]);

    if (is_array($PHPShopSortSearch->sort_array))
        foreach ($PHPShopSortSearch->sort_array as $k => $v) {
            if ($v == $sort_array[1])
                $where['vendor'] = " REGEXP 'i" . $PHPShopSortSearch->sort_category . '-' . $k . "i'";
        }
}

// ��������
if (!empty($_GET['cat']))
    $postfix = '&cat=' . intval($_GET['cat']);
else
    $postfix = null;


// ������� � �������
$PHPShopOrm = new PHPShopOrm($GLOBALS['SysValue']['base']['products']);
//$PHPShopOrm->debug = true;

if (empty($_GET['from']))
    $_GET['from'] = null;

// ������� �����
if ($_GET['from'] == 'header') {
    $where['parent_enabled'] = "='0'";

    // ���� ������ ProductOption
    if (!empty($GLOBALS['SysValue']['base']['productoption']['productoption_system']))
        $where['parent_enabled'] .= " and (name " . $where['name'] . " or uid " . $where['name'] . " or id " . $where['name'] . " or option1 " . $where['name'] . " or option2 " . $where['name'] . " or option3 " . $where['name'] . " or option4 " . $where['name'] . " or option5 " . $where['name'] . ")";
    else
        $where['parent_enabled'] .= " and (name " . $where['name'] . " or uid " . $where['name'] . " or id " . $where['name'] . ")";

    unset($where['name']);
} elseif ($_GET['from'] != 'search') {

    // ������� �������
    $where['parent_enabled'] = "='0'";
}

// ����� ��������
if (!empty($_GET['parent'])) {
    $where['parent'] = "='" . $_GET['parent'] . "'";
    $where['parent_enabled'] = "='1'";
}

// ����� ����������
if ($PHPShopSystem->ifSerilizeParam('admoption.rule_enabled', 1)) {
    $categoriesOrm = new PHPShopOrm($GLOBALS['SysValue']['base']['categories']);
    $PHPShopOrm->debug = false;
    $categories = $categoriesOrm->getList(array('id'), array('secure_groups' => " REGEXP 'i" . $_SESSION['idPHPSHOP'] . "i' or secure_groups = ''"));
    $categoryIds = array();
    foreach ($categories as $category) {
        $categoryIds[] = $category['id'];
    }

    if (count($categoryIds) > 0 && !isset($where['category']) && !isset($where['(category'])) {
        $where['category'] = sprintf(' IN (%s)', implode(',', $categoryIds));
    }
}

// import id
if (!empty($_GET['import']))
    $where['import_id'] = '="' . PHPShopSecurity::TotalClean($_GET['import']) . '"';

// ����� �� �������� JSON
if (!empty($_GET['search']['value'])) {
    $where['parent_enabled'] .= " and (name LIKE '%" . PHPShopString::utf8_win1251(PHPShopSecurity::TotalClean($_GET['search']['value'])) . "%' or uid LIKE '%" . PHPShopString::utf8_win1251(PHPShopSecurity::TotalClean($_GET['search']['value'])) . "%')";
}

// ����� ��������
if (!empty($_GET['parents'])) {
    $data = $PHPShopOrm->getOne(array('pic_small,parent'), array('id' => '=' . intval($_GET['parents'])));

    $parent_array = @explode(",", $data['parent']);
    if (is_array($parent_array))
        foreach ($parent_array as $v)
            if (!empty($v))
                $parent_array_true[] = $v;

    if (!empty($data['parent'])) {

        $PHPShopInterface->tr_id = 'data-parent="' . $_GET['parents'] . '"';
        $parent_pic = $data['pic_small'];

        // ������� �� 1�
        if ($PHPShopSystem->ifSerilizeParam('1c_option.update_option'))
            $where = array('uid' => ' IN ("' . @implode('","', $parent_array_true) . '")', 'parent_enabled' => "='1'");
        else
            $where = array('id' => ' IN ("' . @implode('","', $parent_array_true) . '")', 'parent_enabled' => "='1'");
    }
}

// ������� ���� ���� ����� �����
$count_view = 0;
if (is_array($memory['catalog.option']))
    foreach ($memory['catalog.option'] as $view)
        if (!empty($view))
            $count_view++;

//if ($count_view > 8 and empty($_COOKIE['fullscreen']))
//unset($memory['catalog.option']['menu']);
// ����� ��������
if ($PHPShopSystem->getParam("shop_type") == 1) {
    $memory['catalog.option']['item'] = 0;
}

$PHPShopOrm->mysql_error = false;
$sklad_enabled = $PHPShopSystem->getSerilizeParam('admoption.sklad_enabled');
//$PHPShopOrm->debug=true;

$data = $PHPShopOrm->select(array('*'), $where, $order, $limit);
if (is_array($data))
    foreach ($data as $row) {

        $PHPShopInterface->productTableRowLabels = [];

        // �������� ��������
        if (empty($row['pic_small']) and ! empty($parent_pic))
            $row['pic_small'] = $parent_pic;

        if (!empty($row['pic_small']))
            $icon = '<img src="' . $row['pic_small'] . '" onerror="this.onerror = null;this.src = \'./images/no_photo.gif\'" class="media-object">';
        else
            $icon = '<img class="media-object" src="./images/no_photo.gif">';

        $PHPShopInterface->path = 'product&return=catalog';

        // �������
        if (!empty($row['uid']) and empty($memory['catalog.option']['uid']))
            $uid = '<div class="text-muted">' . __('���') . ' ' . $row['uid'] . '</div>';
        else
            $uid = null;

        if (!empty($memory['catalog.option']['label']) and ( !empty($row['newtip']) or ! empty($row['spec']) or ! empty($row['sklad']) or isset($row['yml'])) and empty($_GET['parents'])) {
            $uid .= '<div class="text-muted">';

            // �������
            if (!empty($row['newtip']))
                $PHPShopInterface->productTableRowLabels[] = '<a class="label label-info" title="' . __('�������') . '" href="?path=catalog' . $postfix . '&where[newtip]=1">' . __('�') . '</a> ';

            // ���������������
            if (!empty($row['spec']))
                $PHPShopInterface->productTableRowLabels[] = '<a class="label label-success" title="' . __('���������������') . '" href="?path=catalog' . $postfix . '&where[spec]=1">' . __('�') . '</a> ';

            // �����������
            if (!empty($row['sklad']))
                $PHPShopInterface->productTableRowLabels[] = '<a class="label label-success" title="' . __('�����������') . '" href="?path=catalog' . $postfix . '&where[sklad]=1">' . __('�') . '</a> ';
        }

        // �������� ������
        $PHPShopModules->setAdmHandler(__FILE__, 'labels', $row);

        // ��������
        if (!empty($memory['catalog.option']['dimensions'])) {

            $dimensions = null;

            if (!empty($row['length']))
                $dimensions = (int) $row['length'] . " x " . (int) $row['width'] . " x " . (int) $row['height'] . " ��";

            if (!empty($row['weight']) and ! empty($dimensions))
                $dimensions .= ", " . round($row['weight'] / 1000, 2) . " ��";
            elseif (!empty($row['weight']) and empty($dimensions))
                $dimensions = round($row['weight'] / 1000, 2) . " ��";

            if (!empty($dimensions))
                $PHPShopInterface->productTableRowLabels[] = ' <span class="label label-default" style="cursor:pointer" title="' . __($dimensions) . '">' . __('�') . '</span> ';
        }

        $uid .= implode('', $PHPShopInterface->productTableRowLabels);

        // ������
        if (!empty($row['parent']) and empty($row['parent_enabled']))
            $uid .= '<a class="label label-default view-parent" title="' . __('�������') . '" href="#" data-id="' . $row['id'] . '">' . __('�') . '<span class="caret"></span></a> ';

        $uid .= '</div>';

        // Enabled
        if (empty($row['enabled']))
            $enabled = 'text-muted';
        else
            $enabled = null;

        if ($row['items'] < 0 and $sklad_enabled)
            $row['items'] = 0;

        // ��������������
        $sort_list = null;
        $sort = unserialize($row['vendor_array']);
        if (is_array($sort))
            foreach ($sort as $scat => $sorts) {
                if (!empty($PHPShopSortCategory[$scat]) and is_array($PHPShopSortCategory[$scat])) {
                    if (is_array($sorts))
                        foreach ($sorts as $s)
                            if (!empty($PHPShopSort[$s]['name']))
                                $sort_list .= '<a href="?path=sort&id=' . $scat . '" class="text-muted">' . $PHPShopSort[$s]['name'] . '</a>, ';
                }
            }

        $sort_list = substr($sort_list, 0, strlen($sort_list) - 2);

        if (strstr($row['odnotip'], ",")) {
            $odnotip = explode(',', $row['odnotip']);
            if (is_array($odnotip))
                $join = count($odnotip);
            else
                $join = 0;
        } else
            $join = 0;

        $PHPShopInterface->productTableRow = [
            $row['id'],
            array(
                'name' => $icon,
                'link' => '../../shop/UID_' . $row['id'] . '.html',
                'target' => '_blank',
                'align' => 'left',
                'view' => intval($memory['catalog.option']['icon'])
            ),
            array(
                'name' => $row['name'],
                'sort' => 'name',
                'link' => '?path=product&return=catalog.' . $row['category'] . '&id=' . $row['id'],
                'align' => 'left',
                'addon' => $uid,
                'class' => $enabled . $product_class,
                'id' => $row['id'],
                'view' => intval($memory['catalog.option']['name'])
            ),
            array(
                'name' => $row['num'],
                'sort' => 'num',
                'align' => 'center',
                'editable' => 'num_new',
                'view' => intval($memory['catalog.option']['num'])
            ),
            array(
                'name' => $row['id'],
                'sort' => 'id',
                'view' => intval($memory['catalog.option']['id'])
            ),
            array(
                'name' => $row['uid'],
                'sort' => 'uid',
                'view' => intval($memory['catalog.option']['uid'])
            ),
            array(
                'name' => $row['price'],
                'sort' => 'price',
                'editable' => 'price_new',
                'view' => intval($memory['catalog.option']['price'])
            ),
            array(
                'name' => $row['price2'],
                'sort' => 'price2',
                'editable' => 'price2_new',
                'view' => intval($memory['catalog.option']['price2'])
            ),
            array(
                'name' => $row['price3'],
                'sort' => 'price3',
                'editable' => 'price3_new',
                'view' => intval($memory['catalog.option']['price3'])
            ),
            array(
                'name' => $row['price4'],
                'sort' => 'price4',
                'editable' => 'price4_new',
                'view' => intval($memory['catalog.option']['price4'])
            ),
            array(
                'name' => $row['price5'],
                'sort' => 'price5',
                'editable' => 'price5_new',
                'view' => intval($memory['catalog.option']['price5'])
            ),
            array(
                'name' => $row['price_n'],
                'sort' => 'price_n',
                'editable' => 'price_n_new',
                'view' => intval($memory['catalog.option']['price_n'])
            ),
            array(
                'name' => $row['price_purch'],
                'sort' => 'price_purch',
                'editable' => 'price_purch_new',
                'view' => intval($memory['catalog.option']['price_purch'])
            ),
            array(
                'name' => $row['items'],
                'sort' => 'items',
                'align' => 'center',
                'editable' => 'items_new',
                'view' => intval($memory['catalog.option']['item'])
            ),
            array(
                'name' => @$row['items1'],
                'sort' => 'items1',
                'align' => 'center',
                'editable' => 'items1_new',
                'view' => intval($memory['catalog.option']['items1'])
            ),
            array(
                'name' => @$row['items2'],
                'sort' => 'items2',
                'align' => 'center',
                'editable' => 'items2_new',
                'view' => intval($memory['catalog.option']['items2'])
            ),
            array(
                'name' => @$row['items3'],
                'sort' => 'items3',
                'align' => 'center',
                'editable' => 'items3_new',
                'view' => intval($memory['catalog.option']['items3'])
            ),
            array(
                'name' => $join,
                'view' => intval($memory['catalog.option']['join']),
                'sort' => 'odnotip',
            ),
            array(
                'name' => $sort_list . "",
                'view' => intval($memory['catalog.option']['sort']),
                'sort' => 'vendor_array',
            )
        ];

        // �������� ������
        $PHPShopModules->setAdmHandler(__FILE__, 'grid', $row);

        $PHPShopInterface->productTableRow[] = array(
            'action' => array('edit', 'copy', 'url', '|', 'delete', 'id' => $row['id']),
            'align' => 'center',
            'view' => intval($memory['catalog.option']['menu'])
        );
        $PHPShopInterface->productTableRow[] = array(
            'status' => array('enable' => $row['enabled'], 'align' => 'right', 'caption' => array('����', '���')),
            'sort' => 'enabled',
            'view' => intval($memory['catalog.option']['status'])
        );

        $PHPShopInterface->setRow(...$PHPShopInterface->productTableRow);
    }

$total = $PHPShopOrm->select(array("COUNT('id') as count"), $where, $order);

if (isset($_GET['cat'])) {

    if ($_GET['cat'] == 1000001)
        $catname = __('����������� CRM');
    elseif ($_GET['cat'] == 0)
        $catname = __('����������� CSV');
    elseif ($_GET['cat'] == 1000004)
        $catname = __('��������� ������');
    elseif ($_GET['cat'] == 1000005)
        $catname = __('���������� ������');
    else
        $catname = $PHPShopCategory->getName();
}
elseif (isset($_GET['where']))
    $catname = __('�����');
else
    $catname = __('����� ������');

if (empty($_GET['search']['value']))
    $PHPShopInterface->_AJAX["catname"] = PHPShopString::win_utf8($catname) . ' [' . $total['count'] . ']';
else
    $PHPShopInterface->_AJAX["catname"] = PHPShopString::win_utf8(__('�����')) . ' "' . PHPShopSecurity::true_search($_GET['search']['value']) . '"';

if (!empty($total['count'])) {
    $PHPShopInterface->_AJAX["recordsFiltered"] = $total['count'];
} else {
    $PHPShopInterface->_AJAX["data"] = array();
    $PHPShopInterface->_AJAX["recordsFiltered"] = 0;
}

$_SESSION['jsort'] = $PHPShopInterface->_AJAX["sort"];
unset($PHPShopInterface->_AJAX["sort"]);

if (!empty($_GET['parents']))
    exit($PHPShopInterface->_CODE);
else {
    header("Content-Type: application/json");
    exit(json_encode($PHPShopInterface->_AJAX));
}
?>